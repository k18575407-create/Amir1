#!/usr/bin/env bash
set -e
printf 'Building CodePilot APK...\n'
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug --no-daemon
elif [ -x ./gradlew ]; then
  ./gradlew assembleDebug --no-daemon
else
  echo 'Gradle is not installed. Use Codemagic with codemagic.yaml or Android Studio.'
  exit 1
fi
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'

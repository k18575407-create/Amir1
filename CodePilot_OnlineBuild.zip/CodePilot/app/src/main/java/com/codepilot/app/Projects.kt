package com.codepilot.app
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class RunState { RUNNING, SUCCESS, FAILED, NOT_SUPPORTED }

/** All file access goes through resolve(): canonical-path check blocks ../ traversal and symlink escapes. */
class ProjectManager(private val root: File) {
    init { root.mkdirs() }
    private val maxRead = 200_000

    fun projects() = root.listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()
    fun createProject(name: String) { resolve(name, "").mkdirs() }
    fun deleteProject(name: String) { resolve(name, "").deleteRecursively() }

    fun resolve(project: String, rel: String): File {
        require(project.isNotBlank() && !project.contains('/') && !project.contains('\\') && project != "..") { "Bad project name" }
        val base = File(root, project).canonicalFile
        require(base.path.startsWith(root.canonicalPath + File.separator)) { "Path escapes projects dir" }
        val f = File(base, rel).canonicalFile
        require(f.path == base.path || f.path.startsWith(base.path + File.separator)) { "Path escapes project" }
        return f
    }
    fun list(p: String): List<String> {
        val b = resolve(p, "")
        return b.walkTopDown().filter { it != b }.map { it.relativeTo(b).path + if (it.isDirectory) "/" else "" }.sorted().toList()
    }
    fun read(p: String, rel: String): String {
        val f = resolve(p, rel); require(f.isFile) { "Not a file: $rel" }
        val t = f.bufferedReader().use { r -> CharArray(maxRead).let { buf -> String(buf, 0, maxOf(r.read(buf), 0)) } }
        return if (f.length() > maxRead) t + "\n[truncated]" else t
    }
    fun write(p: String, rel: String, text: String) { val f = resolve(p, rel); f.parentFile?.mkdirs(); f.writeText(text) }
    fun edit(p: String, rel: String, old: String, new: String) {
        val t = read(p, rel); require(old.isNotEmpty() && t.split(old).size == 2) { "old_text must match exactly once" }
        write(p, rel, t.replace(old, new))
    }
    fun mkdir(p: String, rel: String) { resolve(p, rel).mkdirs() }
    fun rename(p: String, from: String, to: String) { require(resolve(p, from).renameTo(resolve(p, to))) { "Rename failed" } }
    fun delete(p: String, rel: String) { require(rel.isNotBlank()); resolve(p, rel).deleteRecursively() }
    fun search(p: String, q: String): List<String> {
        val b = resolve(p, "")
        return b.walkTopDown().filter { it.isFile && it.length() < 1_000_000 }.flatMap { f ->
            f.useLines { l -> l.withIndex().filter { q in it.value }.map { "${f.relativeTo(b).path}:${it.index + 1}: ${it.value.trim().take(120)}" }.take(5).toList() }
        }.take(50).toList()
    }
    fun zip(p: String, outRel: String): File {
        val b = resolve(p, ""); val out = resolve(p, outRel)
        out.parentFile?.mkdirs()
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            b.walkTopDown().filter { it.isFile && it != out }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(b).path)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
        }
        return out
    }
}

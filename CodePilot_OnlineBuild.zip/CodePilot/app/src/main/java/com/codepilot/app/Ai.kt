package com.codepilot.app
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Add providers by implementing this. */
interface AiProvider { suspend fun send(system: String, messages: JSONArray, tools: JSONArray): JSONObject }

class AnthropicProvider(private val key: String, private val model: String, private val url: String) : AiProvider {
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
    override suspend fun send(system: String, messages: JSONArray, tools: JSONArray): JSONObject {
        val body = JSONObject().put("model", model).put("max_tokens", 4096)
            .put("system", system).put("messages", messages).put("tools", tools).toString()
        val req = Request.Builder().url(url).header("x-api-key", key).header("anthropic-version", "2023-06-01")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        return suspendCancellableCoroutine { c ->
            val call = http.newCall(req); c.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { c.resumeWithException(e) }
                override fun onResponse(call: Call, r: Response) = r.use {
                    val s = it.body?.string().orEmpty()
                    if (!it.isSuccessful) c.resumeWithException(IOException("HTTP ${it.code}: ${s.take(300)}"))
                    else c.resume(JSONObject(s))
                }
            })
        }
    }
}

private fun tool(name: String, desc: String, vararg props: String): JSONObject {
    val p = JSONObject(); props.forEach { p.put(it, JSONObject().put("type", "string")) }
    return JSONObject().put("name", name).put("description", desc).put("input_schema",
        JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(props.toList())))
}
val TOOLS = JSONArray(listOf(
    tool("list_files", "List all files in the current project"),
    tool("read_file", "Read a file", "path"),
    tool("write_file", "Create/overwrite a file", "path", "content"),
    tool("edit_file", "Replace one exact occurrence of text in a file", "path", "old_text", "new_text"),
    tool("search_files", "Search text in project files", "query"),
    tool("create_folder", "Create a folder", "path"),
    tool("rename_file", "Rename/move a file", "from", "to"),
    tool("delete_file", "Delete a file or folder (user must confirm)", "path"),
    tool("create_zip", "Zip the project", "path")))

class Agent(private val ai: AiProvider, private val pm: ProjectManager, private val project: String,
            private val confirm: suspend (String) -> Boolean) {
    private val system = "You are a coding assistant inside an Android app. Current project: '$project'. " +
        "Use tools to read/edit project files. You cannot execute code; never claim code was run."

    suspend fun run(history: JSONArray, onText: (String) -> Unit) {
        repeat(8) {
            val resp = ai.send(system, history, TOOLS)
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") == "text") onText(b.getString("text"))
                if (b.getString("type") == "tool_use") {
                    val out = try { withContext(Dispatchers.IO) { exec(b.getString("name"), b.getJSONObject("input")) } }
                              catch (e: CancellationException) { throw e } catch (e: Exception) { "ERROR: ${e.message}" }
                    results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out))
                }
            }
            if (results.length() == 0) return
            history.put(JSONObject().put("role", "user").put("content", results))
        }
    }

    private suspend fun exec(n: String, a: JSONObject): String = when (n) {
        "list_files" -> pm.list(project).joinToString("\n").ifEmpty { "(empty)" }
        "read_file" -> pm.read(project, a.getString("path"))
        "write_file" -> { pm.write(project, a.getString("path"), a.getString("content")); "written" }
        "edit_file" -> { pm.edit(project, a.getString("path"), a.getString("old_text"), a.getString("new_text")); "edited" }
        "search_files" -> pm.search(project, a.getString("query")).joinToString("\n").ifEmpty { "no matches" }
        "create_folder" -> { pm.mkdir(project, a.getString("path")); "ok" }
        "rename_file" -> { pm.rename(project, a.getString("from"), a.getString("to")); "ok" }
        "delete_file" -> if (confirm("Delete '${a.getString("path")}'?")) { pm.delete(project, a.getString("path")); "deleted" } else "User declined deletion"
        "create_zip" -> "created ${pm.zip(project, a.getString("path")).name}"
        else -> "Unknown tool"
    }
}

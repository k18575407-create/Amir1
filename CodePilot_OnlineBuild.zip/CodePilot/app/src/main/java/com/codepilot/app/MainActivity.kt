package com.codepilot.app
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Msg(val role: String, val text: String)

class VM(app: Application) : AndroidViewModel(app) {
    val pm = ProjectManager(File(app.filesDir, "projects"))
    val prefs = SecureStore.prefs(app)
    val msgs = mutableStateListOf<Msg>()
    val files = mutableStateListOf<String>()
    var busy by mutableStateOf(false)
    var project by mutableStateOf("MyProject")
    var confirmText by mutableStateOf<String?>(null)
    private var pending: CompletableDeferred<Boolean>? = null
    private var job: Job? = null
    private val history = JSONArray()
    init { pm.createProject(project); refresh() }

    fun refresh() { files.clear(); files.addAll(pm.list(project)) }
    fun online(): Boolean {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetwork != null
    }
    fun answerConfirm(ok: Boolean) { pending?.complete(ok); confirmText = null }
    fun stop() { job?.cancel() }

    fun send(text: String) {
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) { msgs.add(Msg("error", "Set your API key in Settings first.")); return }
        history.put(JSONObject().put("role", "user").put("content", text))
        msgs.add(Msg("user", text)); msgs.add(Msg("assistant", ""))
        val idx = msgs.lastIndex
        busy = true
        val provider = AnthropicProvider(key, prefs.getString("model", "claude-sonnet-5-5")!!,
            prefs.getString("url", "https://api.anthropic.com/v1/messages")!!)
        job = viewModelScope.launch {
            try {
                Agent(provider, pm, project) { q ->
                    pending = CompletableDeferred(); confirmText = q; pending!!.await()
                }.run(history) { t -> msgs[idx] = Msg("assistant", msgs[idx].text + t + "\n"); refresh() }
            } catch (e: CancellationException) { msgs.add(Msg("error", "Stopped.")) }
            catch (e: Exception) { msgs.add(Msg("error", e.message ?: "Request failed")) }
            finally { busy = false; refresh() }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

@Composable fun App(vm: VM = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    val names = listOf("Chat", "Files", "Preview", "Settings")
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        if (!vm.online()) Text("OFFLINE MODE", Modifier.fillMaxWidth().padding(4.dp), color = MaterialTheme.colorScheme.error)
        Box(Modifier.weight(1f)) {
            when (tab) { 0 -> Chat(vm); 1 -> Files(vm); 2 -> Preview(vm); else -> SettingsScreen(vm) }
        }
        NavigationBar { names.forEachIndexed { i, n -> NavigationBarItem(tab == i, { tab = i }, { }, label = { Text(n) }) } }
    }
    vm.confirmText?.let { q ->
        AlertDialog(onDismissRequest = { vm.answerConfirm(false) }, title = { Text("Confirm") }, text = { Text(q) },
            confirmButton = { TextButton({ vm.answerConfirm(true) }) { Text("Yes") } },
            dismissButton = { TextButton({ vm.answerConfirm(false) }) { Text("No") } })
    }
}

@Composable fun Chat(vm: VM) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(8.dp)) {
            items(vm.msgs) { m ->
                SelectionContainer { Text("${m.role}: ${m.text}", Modifier.padding(vertical = 6.dp),
                    color = if (m.role == "error") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) }
            }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.padding(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Ask about your code…") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            if (vm.busy) Button({ vm.stop() }) { Text("Stop") }
            else Button({ if (input.isNotBlank()) { vm.send(input.trim()); input = "" } }) { Text("Send") }
        }
    }
}

@Composable fun Files(vm: VM) {
    var open by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    if (open == null) Column(Modifier.padding(8.dp)) {
        Row { OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), label = { Text("New file e.g. index.html") }, singleLine = true)
            Button({ runCatching { vm.pm.write(vm.project, newName, ""); vm.refresh(); newName = "" } }) { Text("Add") } }
        LazyColumn { items(vm.files) { f ->
            Text(f, Modifier.fillMaxWidth().clickable(enabled = !f.endsWith("/")) {
                runCatching { text = vm.pm.read(vm.project, f); open = f } }.padding(14.dp), fontFamily = FontFamily.Monospace) } }
    } else Column(Modifier.padding(8.dp)) {
        Row { Text(open!!, Modifier.weight(1f)); Button({ vm.pm.write(vm.project, open!!, text); open = null; vm.refresh() }) { Text("Save") }
            TextButton({ open = null }) { Text("Close") } }
        OutlinedTextField(text, { text = it }, Modifier.fillMaxSize().horizontalScroll(rememberScrollState()),
            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace))
    }
}

@Composable fun Preview(vm: VM) {
    var reload by remember { mutableStateOf(0) }
    Column {
        Button({ reload++ }, Modifier.padding(8.dp)) { Text("PREVIEW (reload)") }
        key(reload) {
            AndroidView(factory = { ctx ->
                val dir = vm.pm.resolve(vm.project, "")
                val loader = WebViewAssetLoader.Builder()
                    .addPathHandler("/p/", WebViewAssetLoader.InternalStoragePathHandler(ctx, dir)).build()
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true; settings.allowFileAccess = false
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(r.url)
                    }
                    loadUrl("https://appassets.androidplatform.net/p/index.html")
                }
            }, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable fun SettingsScreen(vm: VM) {
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(vm.prefs.getString("model", "claude-sonnet-5-5")!!) }
    var url by remember { mutableStateOf(vm.prefs.getString("url", "https://api.anthropic.com/v1/messages")!!) }
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("API key is stored encrypted (Android Keystore).")
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text(if (vm.prefs.contains("api_key")) "API key (saved — enter to replace)" else "API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Endpoint") }, singleLine = true)
        Button({ vm.prefs.edit().apply { if (key.isNotBlank()) putString("api_key", key.trim()); putString("model", model); putString("url", url) }.apply(); key = "" }) { Text("Save") }
    }
}

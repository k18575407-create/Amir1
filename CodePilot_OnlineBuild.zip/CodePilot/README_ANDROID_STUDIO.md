# CodePilot — Android Studio build guide

This is an Android Studio project using Kotlin + Jetpack Compose.

## Requirements
- Android Studio Koala (or newer)
- JDK 17
- Android SDK 34

## Build
1. Open the `CodePilot` folder in Android Studio.
2. Let Gradle sync and download dependencies.
3. Select **Build > Generate Signed App Bundle / APK > APK**.
4. Choose `release`, create/select a signing keystore, and finish.
5. The APK will be under `app/release/`.

For a quick debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## App setup
Open **Settings**, enter your Anthropic API key, model, and endpoint, then use Chat.

The API key is stored using Android Keystore-backed encrypted preferences.

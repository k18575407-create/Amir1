# Build CodePilot online

This project includes `codemagic.yaml` for building an installable Android debug APK.

## Codemagic
1. Put this project in a GitHub repository.
2. Add the repository to Codemagic as a Native Android app.
3. Start the `android-debug` workflow.
4. Download `app-debug.apk` from the build artifacts.

The APK is a debug build intended for installation/testing on an Android phone.
